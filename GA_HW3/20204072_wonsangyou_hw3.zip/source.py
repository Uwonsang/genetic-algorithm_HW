import numpy as np
from tqdm import tqdm
import matplotlib.pyplot as plt
import utils

##parameter
num_generation = 300
ratio = 0.95
crossover_prob = 0.9
mutation_prob = 0.01
D = 30


def generation(population):

    fitness_list = list()
    for ind in range(len(population)):
        fitness_list.append(utils.fitness_function(population[ind]))
    fitness_array = np.array(fitness_list)

    zeta_list = utils.zeta(population, D)
    new_fitness_list = fitness_array / zeta_list

    tournament_pop = utils.tournament_selection(population, new_fitness_list)
    crossover_pop = utils.crossover(tournament_pop, crossover_prob)
    mutation_pop = utils.mutation(crossover_pop, mutation_prob)
    final_pop = utils.overlap(population, mutation_pop, new_fitness_list, ratio)

    average = utils.get_average(final_pop)
    best = utils.get_best(final_pop)

    return final_pop, average, best

def main():
    fitness_avg = list()
    fitness_best = list()
    population = utils.initialize(seed_num = 42)

    for _ in tqdm(range(num_generation)):

        offspring_pop, avg, best = generation(population)
        population = offspring_pop
        fitness_avg.append(avg)
        fitness_best.append(best)

    plt.title("FourMax Problem fitness trace")
    plt.plot(range(300), fitness_avg, label="Fitness_average")
    plt.plot(range(300), fitness_best, label="Fitness_best")
    plt.legend()
    plt.show()

    pop_string = ""
    for i in range(100):
        line = "".join(["1" if b else "0" for b in population[i]])
        pop_string += line
        pop_string += "\n"


    with open("fourmax.txt", "w") as f:
        f.write(pop_string)


if __name__ == "__main__":
    main()
